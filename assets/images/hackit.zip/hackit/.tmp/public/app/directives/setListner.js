app.directive('setListner', function (){ 

    return function(scope, elem, attr) {
        var events = attr['setListner'].split(',');
   	    elem[0].id = attr.id;

       	function dragstartElement(e){
            e.dataTransfer.uibuild_name = name;
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('Text', e.target.id);
            document.getElementById('scrollBottom').classList.add('show');
            document.getElementById('scrollTop').classList.add('show');
        }
        function dragoverElement(e){
            e.dataTransfer.dropEffect = 'move';
            if(e.preventDefault) e.preventDefault();
             this.classList.add('over');
            return false;
        }
        function dragenterElement(e){
            this.classList.add('over');
            return false;
        }
        function dragleaveElement(e){
            this.classList.remove('over');
            return false;
        }
        function dragoverElementTop(e){
            if(!scope.ElementisDragging) {
                scope.ElementisDragging = true;
                $("body, html").animate({ scrollTop: $('#scrollTop').offset().top - 500 },500,function(){
                    scope.ElementisDragging = false;
                });
            }
        }
        function dragoverElementBottom(e){
            if(!scope.ElementisDragging) {
                scope.ElementisDragging = true;
                $("body, html").animate({ scrollTop: $('#scrollTop').offset().top + 500 },500,function(){
                    scope.ElementisDragging = false;
                });
            }
        }

        function dragendElement(e){
            if(e.preventDefault) { e.preventDefault(); }
            if(e.stopPropagation) { e.stopPropagation(); }
            document.getElementById('scrollBottom').classList.remove('show');
            document.getElementById('scrollTop').classList.remove('show');
        }

        function dropElement(e){
            if(e.preventDefault) { e.preventDefault(); }
            if(e.stopPropagation) { e.stopPropagation(); }
            this.classList.remove('over');
            document.getElementById('scrollBottom').classList.remove('show');
            document.getElementById('scrollTop').classList.remove('show');

            if(((this.id).indexOf(e.dataTransfer.getData('Text')) == -1)){
                if(/_drop/.test(this.id)){
                    if(/_trigger/.test(e.dataTransfer.getData('Text'))){
                         new scope.contentObject($('#'+e.dataTransfer.getData('Text')).attr('buildData'), 'el-'+scope.contentElements.length, this.id, true);
                         scope.elCounter++;
                    } else {
                        scope.moveElement(e.dataTransfer.getData('Text'), this.id);
                    }
                } else if(/_layer/.test(this.id)){
                   /* ### Drop On Element */
                }
            }
            return false;
        }

   	for(var i = 0; i < events.length; i++){
    	switch(events[i]){
            case 'dragstart':
                document.getElementById(attr.id).addEventListener(
                    'dragstart',
                    dragstartElement,
                    false
                );
            break;
            case 'dragover':
                document.getElementById(attr.id).addEventListener(
                    'dragover',
                    dragoverElement,
                    false
                );
            break;
            case 'dragenter':
                document.getElementById(attr.id).addEventListener(
                    'dragenter',
                    dragenterElement,
                    false
                );
            break;
            case 'dragleave':
                document.getElementById(attr.id).addEventListener(
                    'dragleave',
                    dragleaveElement,
                    false
                );
            break;
            case 'drop':
                document.getElementById(attr.id).addEventListener(
                    'drop',
                    dropElement,
                    false
                );
            break;
            case 'dragend':
                document.getElementById(attr.id).addEventListener(
                    'dragend',
                    dragendElement,
                    false
                );
            break;
        }
    }

    document.getElementById('scrollTop').addEventListener(
        'dragover',
        dragoverElementTop,
        false
    )
    document.getElementById('scrollBottom').addEventListener(
        'dragover',
        dragoverElementBottom,
        false
    )
}
});