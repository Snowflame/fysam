// validate-after="d.m.y h:i:s"
app.directive('validateAfter', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
            var regexString = new RegExp('^'+validateAfter
              .replace("d", "[0-9]{1,2}")
              .replace("m", "[0-9]{1,2}")
              .replace("s", "[0-9]{1,2}")
              .replace("i", "[0-9]{1,2}")
              .replace("h", "[0-9]{1,2}")
              .replace("y", "([0-9]{2}|[0-9]{4})")
              .replace(/\./g, '\\.') + '$');
            var valid = regexString.test(value);
            ngModel.$setValidity('validateAfter', valid);
            return valid ? value : undefined;
          });
          ngModel.$formatters.unshift(function(value) {
            var regexString = new RegExp('^'+validateAfter
              .replace("d", "[0-9]{1,2}")
              .replace("m", "[0-9]{1,2}")
              .replace("s", "[0-9]{1,2}")
              .replace("i", "[0-9]{1,2}")
              .replace("h", "[0-9]{1,2}")
              .replace("y", "([0-9]{2}|[0-9]{4})")
              .replace(/\./g, '\\.') + '$');
            var valid = regexString.test(value);
            ngModel.$setValidity('validateAfter', valid);
            return value;
          });
      }
   };
});

// validate-alpha
app.directive('validateAlpha', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
             var valid = new RegExp('^[A-Za-z]*$').test(value);
             ngModel.$setValidity('validateAlpha', valid);
             return valid ? value : undefined;
          });

          ngModel.$formatters.unshift(function(value) {
             ngModel.$setValidity('validateAlpha', new RegExp('^[A-Za-z]*$').test(value));
             return value;
          });
      }
   };
});

// validate-minLength
app.directive('validateRequired', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          var validateRequired = parseInt(attr.validateRequired);
          ngModel.$parsers.unshift(function(value) {
            var valid = false;
            if(typeof value != 'undefined' && value != '')
              valid = true;

             ngModel.$setValidity('validateRequired', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
            var valid = false;
            if(typeof value != 'undefined' && value != '')
              valid = true;


            ngModel.$setValidity('validateRequired', valid);
             return value;
          });
      }
   };
});

// validate-minLength
app.directive('validateMinlength', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          var validateMinlength = parseInt(attr.validateMinlength);
          ngModel.$parsers.unshift(function(value) {
            var valid = false;
            if(typeof value != 'undefined')
              valid = value.length >= validateMinlength;

             ngModel.$setValidity('validateMinlength', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
            var valid = false;
            if(typeof value != 'undefined')
              valid = value.length >= validateMinlength;

            ngModel.$setValidity('validateMinlength', valid);
             return value;
          });
      }
   };
});

// validate-maxLength
app.directive('validateMaxlength', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          var validateMaxlength = parseInt(attr.validateMaxlength);
          ngModel.$parsers.unshift(function(value) {
            var valid = false;
            if(typeof value != 'undefined')
              valid = value.length <= validateMaxlength;

             ngModel.$setValidity('validateMaxlength', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
            var valid = false;
            if(typeof value != 'undefined')
              valid = value.length <= validateMaxlength;

             ngModel.$setValidity('validateMaxlength', valid);
             return value;
          });
      }
   };
});

// validate-alphadashed
app.directive('validateAlphadashed', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
             var valid = new RegExp('^[A-Za-z\/]*$').test(value);
             ngModel.$setValidity('validateAlphadashed', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
             ngModel.$setValidity('validateAlphadashed', new RegExp('^[A-Za-z\/]*$').test(value));
             return value;
          });
      }
   };
});

// validate-alphanumeric
app.directive('validateAlphanumeric', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
             var valid = new RegExp('^[A-Za-z0-9]*$').test(value);
             ngModel.$setValidity('validateAlphanumeric', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
             ngModel.$setValidity('validateAlphanumeric', new RegExp('^[A-Za-z0-9]*$').test(value));
             return value;
          });
      }
   };
});

// validate-alphanumericdashed
app.directive('validateAlphanumericdashed', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
             var valid = new RegExp('^[A-Za-z0-9\/]*$').test(value);
             ngModel.$setValidity('validateAlphanumericdashed', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
             ngModel.$setValidity('validateAlphanumericdashed', new RegExp('^[A-Za-z0-9\/]*$').test(value));
             return value;
          });
      }
   };
});

// validate-integer
app.directive('validateInteger', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
             var valid = new RegExp('^[0-9\/]*$').test(value);
             ngModel.$setValidity('validateInteger', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
             ngModel.$setValidity('validateInteger', new RegExp('^[0-9\/]*$').test(value));
             return value;
          });
      }
   };
});

// validate-float
app.directive('validateFloat', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
             var valid = new RegExp('^[0-9\/]*\.[0-9]+$|^[0-9\/]*$').test(value);
             ngModel.$setValidity('validateFloat', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
             ngModel.$setValidity('validateFloat', new RegExp('^[0-9\/]*\.[0-9]+$|^[0-9\/]*$').test(value));
             return value;
          });
      }
   };
});

// validate-boolean
app.directive('validateBoolean', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          ngModel.$parsers.unshift(function(value) {
             var valid = new RegExp('^[true|false]*$').test(value);
             ngModel.$setValidity('validateBoolean', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
             ngModel.$setValidity('validateBoolean', new RegExp('^[true|false]*$').test(value));
             return value;
          });
      }
   };
});

// validate-blacklist="name, tic, tow"
app.directive('validateBlacklist', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {

          ngModel.$parsers.unshift(function(value) {
             var validateBlacklist = attr.validateBlacklist.split(',');
             var valid = validateBlacklist.indexOf(value) === -1;

            if(typeof attr.validateBlacklistIgnore != "undefined" && !valid){
              if(value == attr.validateBlacklistIgnore)
                valid = !valid;
            }
             ngModel.$setValidity('validateBlacklist', valid);
             return value;
          });

          ngModel.$formatters.unshift(function(value) {
            var validateBlacklist = attr.validateBlacklist.split(',');
            var valid = validateBlacklist.indexOf(value) === -1;

            if(typeof attr.validateBlacklistIgnore != "undefined" && !valid){
              if(value == attr.validateBlacklistIgnore)
                valid = !valid;
            }
             ngModel.$setValidity('validateBlacklist', valid);
             return value;
          });

      }
   };
});

// validate-whitelist="name, tic, tow"
app.directive('validateWhitelist', function (){ 
   return {
      require: 'ngModel',
      link: function(scope, elem, attr, ngModel) {
          var validateWhitelist = attr.validateWhitelist.split(',');
          ngModel.$parsers.unshift(function(value) {
              if(elem[0].nodeName == "SELECT"){
                  testvalue = value.value;
                  returnvalue = value.label;
              } else {
                  testvalue = value;
                  returnvalue = value;
              }

             var valid = validateWhitelist.indexOf(testvalue) === -1;
             ngModel.$setValidity('validateWhitelist', !valid);
             return value;
          });
          ngModel.$formatters.unshift(function(value) {
              testvalue = value;
             ngModel.$setValidity('validateWhitelist', !(validateWhitelist.indexOf(testvalue) === -1));
             return value;
          });
      }
   };
});