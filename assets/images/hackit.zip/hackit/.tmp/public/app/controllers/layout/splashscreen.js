app.controller('splashscreenController', function ($scope, $location) {
    $scope.splashscreenClass = "inaktive"
});