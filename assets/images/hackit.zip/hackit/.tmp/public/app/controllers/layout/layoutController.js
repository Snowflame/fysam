app.controller('LayoutController', function ($scope, $modal, $location, layoutService, PARCIALFORMAT, PARCIALDIR) {
    $scope.stars = {};
    $scope.loadStars = {loading: true};

    function init() { 
        layoutService.listLayout(function(data){
            $scope.loadStars.loading = false;
            $scope.stars = data;
        });
    }

    $scope.openAddTableModal = function () {
        var modalInstance = $modal.open({
            templateUrl: PARCIALDIR+'/views/layout/modal/createLayout'+PARCIALFORMAT,
            controller: createLayoutModalInstanceCtrl,
            resolve: {
                layouts: function () {
                    return $scope.layouts;
                }
            }
        });

        modalInstance.result.then(function (layoutID) {
            $location.path('/layout/'+layoutID);
        });
    };

    init();
});
