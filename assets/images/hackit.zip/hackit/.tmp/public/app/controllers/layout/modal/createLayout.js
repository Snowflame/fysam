var createLayoutModalInstanceCtrl = function ($scope, $modalInstance, layoutService, layouts) {
    $scope.layout = {name:'', save:false};

    function init(){
        var list = [];
        for(index in layouts){
           list.push(layouts[index].name);
        }
        $scope.layouts = list.toString();
    }

    $scope.send = function () {
        $scope.layouts.save = true;
        layoutService.createLayout($scope.layout.name, function(data){
            $scope.layout.save = false;
            $modalInstance.close(data.id);
        });
    };
    $scope.abort = function () {
        $modalInstance.dismiss('cancel');
    };

    init();
};