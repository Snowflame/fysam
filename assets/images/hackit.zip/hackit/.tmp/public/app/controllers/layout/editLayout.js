app.controller('editLayoutController', function ($scope, $compile, $routeParams, $translate, $location, $modal, layoutService, APPDIR, PARCIALFORMAT, PARCIALDIR) {

    $scope.star = {name:'',id:0};
    $scope.showDestroy=false;

    $scope.posts = [];


    function init() {
        if(typeof $routeParams.starID != "undefined"){
            $scope.star.id = $routeParams.starID;
            
            //layoutService.getLayout($scope.layout.id, function(data){
                //$scope.posts = data;
                //$scope.$apply();
            //});
        } else {
            $location.path('/star');
        }
    }

    init();
});
