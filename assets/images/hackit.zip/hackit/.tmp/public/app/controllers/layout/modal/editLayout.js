var settingModalInstanceCtrl = function ($scope, $modalInstance, layout) {
    $scope.layout = layout;

    $scope.send = function () {
        $modalInstance.close($scope.layout);
    };
    $scope.abort = function () {
        $modalInstance.dismiss('cancel');
    };

};