var assetManagerModalInstanceCtrl = function ($scope, $modalInstance, contentElements) {
    $scope.layout = {name:'', save:false};

    function init(){
    }

    $scope.send = function () {
    };
    $scope.abort = function () {
        $modalInstance.dismiss('cancel');
    };

    init();
};