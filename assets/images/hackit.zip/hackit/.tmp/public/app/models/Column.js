app.factory('Column', function(){
     
    var Column = function(){
	    this.blured = {};
	    this.val = {};

	    this.delete = false;
	    this.edit = false;
	    this.save = false;
	    this.new = true;

	    this.val.key = false;
	    this.val.name = '';
	    this.val.count = false;
	    this.val.type = {
	    	label:'Zeichenkette',
	    	value:'string'
	    };
	    this.val.defaultvalue = '';

	    this.blured.key = false;
	    this.blured.name = false;
	    this.blured.count = false;
	    this.blured.type = false;
	    this.blured.defaultvalue = false;
	}

    Column.create = function(){
    	return new Column;
    }

    Column.setValue = function(key, value){
    	this.val[key] = name;
    }

    return Column; 
});