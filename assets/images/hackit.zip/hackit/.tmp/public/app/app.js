﻿/// <reference path="../Scripts/angular-1.1.4.js" />

/*#######################################################################
  
  Dan Wahlin
  http://twitter.com/DanWahlin
  http://weblogs.asp.net/dwahlin
  http://pluralsight.com/training/Authors/Details/dan-wahlin

  Normally like to break AngularJS apps into the following folder structure
  at a minimum:

  /app
      /controllers      
      /directives
      /services
      /partials
      /views

  #######################################################################*/

var app = angular.module('boolieApp', ['ngRoute', 'ui.bootstrap', 'pascalprecht.translate']);

app.config(function ($routeProvider) {

  $routeProvider
      .when('/star',
          {
              controller: 'LayoutController',
              templateUrl: 'views/overview'
          })
      .when('/star/:starID', 
          {
              controller: 'editLayoutController',
              templateUrl: '/views/star'
          })
      .otherwise({ redirectTo: '/star' });
});

app.config(['$translateProvider', function ($translateProvider) {
        $translateProvider.translations('de', {
            'LANG_SERVER_ERROR': 'Verbindungsfehler'

        });

        $translateProvider.preferredLanguage('de');
}]);

app.constant("APPDIR", "http://192.168.2.164:1337/js/app");
app.constant("APIDIR", "http://192.168.2.164:1337/api/v1/");
app.constant("PARCIALFORMAT", "");
app.constant("PARCIALDIR", "http://192.168.2.164:1337");

