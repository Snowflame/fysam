app.service('dataformatsService', function ($rootScope, $http, APIDIR) {
   
      var datatypes = [
        {label:'Text', value:'text'},
        {label:'KText ', value:'string'},
        {label:'Zahl', value:'integer'},
        {label:'Kommazahl', value:'float'},
        {label:'Ja/Nein', value:'boolean'},
        {label:'Datum', value:'date'},
        {label:'Datum/Zeit', value:'datetime'}      
      ];
     
    function getDataformatsList(){
      return 'text,string,integer,float,boolean,date,datetime';
    }

    function setDataFormatSelect(val){
      return {"value":val};
    }

    return {
      getDataformatsFormSelect: function () {
        return datatypes;
      },
      getDataformatsList: function(){
        return getDataformatsList();
      },
      setDataFormatSelect: function(value){
        return setDataFormatSelect(value);
      }
    };
});
