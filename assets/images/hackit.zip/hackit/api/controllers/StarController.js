/**
 * StarController
 *
 * @description :: Server-side logic for managing stars
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

