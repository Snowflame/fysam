/**
 * PostinfoController
 *
 * @description :: Server-side logic for managing postinfoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

